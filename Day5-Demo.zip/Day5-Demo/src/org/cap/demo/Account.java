package org.cap.demo;

public class Account {
	
	private double balance=6000;
	
	synchronized public void withdrawal(double amount) {
		System.out.println("Withdraw Started..............");
		
		if(this.balance<amount) {
			try {
				System.out.println("I am waiting==========================");
				//wait();
				
				wait(1000);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			this.balance-=amount;
		}
		System.out.println("Updated balance:" + Thread.currentThread().getName() +"==>" + this.balance);
		
		System.out.println("Withdraw Completed..............");
	}
	
	
	synchronized public void deposit(double amount) {
		System.out.println("Deposit Started..............");
		this.balance+=amount;
		notifyAll();
		System.out.println("Updated balance:"+ Thread.currentThread().getName()+"==>" + this.balance);
		System.out.println("Deposit Completed..............");
	}

}
