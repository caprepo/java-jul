package org.cap.demo;


public class MyTable {
	
	private static int count=100;
	
	synchronized public static void printTable(int num) {
		System.out.println("Method Started...." + num);
		System.out.println("Count:" + count++);
		//synchronized(this) {
			for(int i=1;i<=15;i++)
				System.out.println(i+"*"+num+ "=" + (i*num) 
					+"===>" + Thread.currentThread().getName());
		//}
		
		System.out.println("Method Ended...." + num);
	}
	

	private int num;
	
	public MyTable() {
		
	}
	
	public MyTable(int num) {
		this.num=num;
	}

	
	
}
