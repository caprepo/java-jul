package org.cap.demo;

public class TestInterThread {

	public static void main(String[] args) {

		final Account account=new Account();
		
		Runnable runnable=new Runnable() {
			
			@Override
			public void run() {
				account.withdrawal(3000);
			}
		};
		
		Thread t1=new Thread(runnable);
		t1.start();
		
		new Thread() {
			@Override
			public void run() {
				account.deposit(1000);
			}
		}.start();
		
		
		new Thread() {
			@Override
			public void run() {
				account.withdrawal(40000);
			}
		}.start();
		
		
		
	}

}
