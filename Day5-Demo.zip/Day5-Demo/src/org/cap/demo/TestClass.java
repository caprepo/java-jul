package org.cap.demo;

public class TestClass {

	public static void main(String[] args) {
		
		/*
		 * MyThread t1=new MyThread(12); MyThread t2=new MyThread(9); MyThread t3=new
		 * MyThread(11);
		 */
		
		//MyTable obj=new MyTable();
		
		Thread t1=new Thread() {
			@Override
			public void run() {
				MyTable.printTable(12);
			}
		};
		t1.start();
		
		
		new Thread() {
			@Override
			public void run() {
				MyTable.printTable(11);
			}
		}.start();
		
		
		new Thread() {
			@Override
			public void run() {
				MyTable.printTable(13);
			}
		}.start();
	}

}
