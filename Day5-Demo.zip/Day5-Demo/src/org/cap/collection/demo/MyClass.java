package org.cap.collection.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class MyClass {

	public static void main(String[] args) {
		List<Employee> employees=new ArrayList<Employee>();
		//Set<Employee> employees=new HashSet<Employee>();
		//Set<Employee> employees=new TreeSet<Employee>();
		
		employees.add(new Employee(123, "Tom", "Kamal"));
		employees.add(new Employee(1234, "Jack", "Thomson"));
		employees.add(new Employee(123, "Tom", "Kamal"));
		employees.add(new Employee(1234, "Jack", "Thomson"));
		employees.add(new Employee(6546, "Kamal", "Singh"));
		employees.add(new Employee(6546, "Kamal", "Singh"));
		employees.add(new Employee(1234, "Jack", "Thomson"));
		
		Collections.sort(employees);
		
		for(Employee emp:employees)
			System.out.println(emp);
		
		System.out.println("==============================");
		
		Comparator<Employee> sortByFirstname=new Comparator<Employee>() {
			
			@Override
			public int compare(Employee emp1, Employee emp2) {
				if(emp1.getFirstName().compareTo(emp2.getFirstName())<0)
					return -1;
				else if(emp1.getFirstName().compareTo(emp2.getFirstName())>0)
					return 1;
				else
					return 0;
			}
		};
		
		Collections.sort(employees,sortByFirstname);
		
		for(Employee emp:employees)
			System.out.println(emp);
		
		
		System.out.println("==============================");
		Collections.sort(employees,new SortByLastName());
		
		for(Employee emp:employees)
			System.out.println(emp);
	}

}
