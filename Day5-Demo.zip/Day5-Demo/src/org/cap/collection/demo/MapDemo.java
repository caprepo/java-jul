package org.cap.collection.demo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		
		//Map<Integer, String> maps=new HashMap<Integer, String>();
		
		//Map<Integer, String> maps=new LinkedHashMap<Integer, String>();
		
		//Map<Integer, String> maps=new Hashtable<Integer, String>();
		Map<Integer, String> maps=new TreeMap<Integer, String>();
		
		Map<Employee, String> emps=new TreeMap<Employee, String>();
		
		maps.put(12, "Tom");
		maps.put(12, "Jerrry");
		maps.put(13, "Jack");
		maps.put(112, "hendry");
		maps.put(1267, "Kamal");
		//maps.put(12, "Tom");
		maps.put(1267, "Kamal");
		//maps.put(null, "Kamal");
		//maps.put(null, "dsfsadsa");
		//maps.put(2343, null);
		
		System.out.println(maps);
		
		//All keys
		Set<Integer> keys=maps.keySet();
		for(Integer key:keys) {
			
			System.out.println(key + " -" + maps.get(key));
		}
			
		Iterator<Integer> iterator1= keys.iterator();
		while (iterator1.hasNext()) {
			Integer integer = (Integer) iterator1.next();
			if(integer==13)
				iterator1.remove();
		}
		
		Collection<String> values= maps.values();
		Iterator<String> iterator= values.iterator();
		
		while (iterator.hasNext()) {
			String value = (String) iterator.next();
			
			System.out.println(value);
			
		}
		
		Set<Entry<Integer,String>> entries=  maps.entrySet();
		System.out.println(entries);
		
		for(Entry<Integer, String> entry:entries) {
			if(entry.getKey()==12)
				entry.setValue("Annie");
			System.out.println(entry.getKey() + " -->" + entry.getValue());
		}
		
		System.out.println(maps);
	}

}
