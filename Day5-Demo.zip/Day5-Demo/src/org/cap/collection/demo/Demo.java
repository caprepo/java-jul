package org.cap.collection.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

public class Demo {

	public static void main(String[] args) {
		
		//ArrayList<String> names=new ArrayList<String>();
		//ArrayList<String> names=new ArrayList<>();
		//List<String> names=new ArrayList<>();
		//Collection<String> names=new ArrayList<String>();
		
		//List<String> names=new Vector<String>();
		
		//Vector<String> names=new Vector<String>();
		Vector<String> names=new Vector<String>(100,800);
		
		names.add("tom");
		names.add("tom");
		names.add("jerry");
		names.add("tom");
		names.add("jack");
		names.add("tom");
		names.add("ram");
		//names.add(null);
		names.add("null");
		//names.add(null);
		
		//System.out.println(names);
		
		/*
		 * for(String str:names) System.out.println(str);
		 */
		
		//Move Forward
		Iterator<String> iterable=names.iterator();
		while(iterable.hasNext()) {
			String str=iterable.next();
			if(str.equals("tom"))
				iterable.remove();
			
			System.out.print(str +" ,") ;
		}
		System.out.println();
		
		//Both directions 
		ListIterator<String> listIterator= names.listIterator();
		while(listIterator.hasNext()) {
		
			String str=listIterator.next();
			if(str.equals("null"))
				listIterator.set("Capgemini");
			System.out.print(str +"->") ;
		}
		System.out.println();
		
		
		while(listIterator.hasPrevious()) {
			String str=listIterator.previous();
			System.out.print(str +"->") ;
		}
		System.out.println();
		
		
		Enumeration<String> enumeration= names.elements();
		while(enumeration.hasMoreElements()) {
			String str=enumeration.nextElement();
			System.out.print(str +"=>") ;
		}
		System.out.println();
	}

}
