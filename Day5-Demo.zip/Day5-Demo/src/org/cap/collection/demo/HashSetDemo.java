package org.cap.collection.demo;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class HashSetDemo {

	public static void main(String[] args) {
		
		//Set<Integer> set=new HashSet<Integer>();
		//Set<Integer> set=new LinkedHashSet<Integer>();
		Set<Integer> set=new TreeSet<Integer>();
		set.add(34);
		set.add(423432);
		set.add(34);
		set.add(45);
		set.add(34);
		set.add(45);
		set.add(4);
		set.add(4);
		set.add(3);
		set.add(3);
		//set.add(null);
		
		for(int num:set)
			System.out.print(num+",");
	}

}
