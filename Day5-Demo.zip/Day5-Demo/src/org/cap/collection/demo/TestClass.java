package org.cap.collection.demo;

import java.util.ArrayList;

public class TestClass {

	public static void main(String[] args) {
		ArrayList lst=new ArrayList();
		//Autoboxing
		lst.add(45);//INteger
		lst.add("hello");
		lst.add(45.34);//Double
		lst.add(true);//Boolean
		lst.add('s');
		lst.add(213213213213l);
		
		System.out.println(lst);
		
	}

}
