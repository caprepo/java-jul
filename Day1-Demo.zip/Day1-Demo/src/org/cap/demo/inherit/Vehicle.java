package org.cap.demo.inherit;

public class Vehicle {
	protected int vehicleId=1234;
	protected String vehicleInfo="Details of Vehicle";
	
	public void info() {
		System.out.println(vehicleInfo);
	}

}
