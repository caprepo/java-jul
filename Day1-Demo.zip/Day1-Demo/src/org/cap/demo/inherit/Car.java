package org.cap.demo.inherit;


public class Car extends Vehicle {

	String carName="Maruti";
	double price=34000.0;
	int noOfWheels=4;
	String breakType="Air&Oil";
	
	
	
	public void printCarDetails() {
		info();
		System.out.println("Vehicle ID:" + vehicleId 
			//	+"\nInfo :" + vehicleInfo
				+"\nCar Name:" + carName
				+"\nprice:"  +price
				+"\nNoOfWheels:" + noOfWheels
				+"\nbreakType:" + breakType);
	}
	
}
