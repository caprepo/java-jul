package org.cap.demo.inherit;

public class Automate {

}
