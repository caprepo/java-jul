package org.cap.demo.inherit;

import org.mydemo.Car;

public class MainClass {

	public static void main(String[] args) {
		
		//Car car=new Car();
		//car.printCarDetails();
		
		//Vehicle car=new Car();
		Vehicle car=new Vehicle();
		car.info();
	}

}
