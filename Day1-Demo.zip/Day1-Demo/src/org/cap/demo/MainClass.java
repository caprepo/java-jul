package org.cap.demo;

public class MainClass {
	public static void main(String[] args) {
		Circle circle=new Circle();
		
		//bad Practise
		//circle.radius=3.6f;
		
		//Good Practise
		circle.setRadius(3.5F);
		float ans=circle.calculateArea();
		System.out.println("Area:" + ans);
	}

}
