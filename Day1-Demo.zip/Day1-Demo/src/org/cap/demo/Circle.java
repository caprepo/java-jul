package org.cap.demo;

public class Circle {
	private float radius;
	
	public void setRadius(float myRadius) {
		radius=myRadius;
	}
	
	public float calculateArea() {
		return (22*radius*radius)/7;
	}

	
}
