package org.cap.demo;

public class EmployeeMainClass {

	public static void main(String[] args) {
		Employee employee=new Employee();
		employee.getEmployeeDetails();
		employee.printEmployee();
	}

}
