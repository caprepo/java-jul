package org.cap.demo;


import java.time.LocalDate;
//All class, interfaces, exception
//import java.util.*;
//only Scanner class
import java.util.Scanner;

public class Employee{
	
	private int employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	private LocalDate dateOfJoining=LocalDate.now();
	
	
	
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	//setter
	public void setEmployeeId(int employeeId) {
		//this ref current object
		this.employeeId=employeeId;
	}
	
	//getter
	public int getEmployeeId() {
		return this.employeeId;
	}
	
	public void getEmployeeDetails() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter Employee FirstName:");
		firstName=scanner.next();
		System.out.println("enter Employee LastName:");
		lastName=scanner.next();
		
		System.out.println("enter Employee Id:");
		employeeId=scanner.nextInt();
		
		System.out.println("enter Employee Salary:");
		salary=scanner.nextDouble();
	}
	
	public void printEmployee() {
		System.out.println("Employee ID:" + employeeId 
				+"\nFirstName:" + firstName
				+"\nLastName:" + lastName
				+"\nDateOfJoining:" + dateOfJoining
				+"\nSalary :" + salary
				);
	}

}
