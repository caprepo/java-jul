package org.cap.bank;

public class SimpleInterest {
	
	public double calculateSimpleInterest(double principle, float years, float rateofinterest) {
		return principle*years*rateofinterest;
	}

	public double calculateSimpleInterest(double principle) {
		return principle*5*6.5f;
	}
	
	//public void calculateSimpleInterest(double principle) {
		//System.out.println(principle*5*6.5f);
	//}
	
	public double calculateSimpleInterest(double principle,float years) {
		return principle*years*6.5f;
	}
	
	public static void main(String[] args) {
		SimpleInterest si=new SimpleInterest();
		double interest=si.calculateSimpleInterest(3000.0, 5.0f, 3.5f);
		System.out.println(interest);
		
		interest=si.calculateSimpleInterest(5000);
		System.out.println(interest);
		
		interest=si.calculateSimpleInterest(5000,3.1f);
		System.out.println(interest);
	}
}
