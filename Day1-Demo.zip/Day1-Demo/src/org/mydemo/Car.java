package org.mydemo;

import org.cap.demo.inherit.Vehicle;
import org.cap.demo.inherit.Automate;

public class Car extends Vehicle {

	String carName="Maruti";
	double price=34000.0;
	int noOfWheels=4;
	String breakType="Air&Oil";
	
	@Override
	public void info() {
		System.out.println("Car Information Here.");
	}
	
	public void printCarDetails() {
		super.info();
		System.out.println("Vehicle ID:" + vehicleId 
			//	+"\nInfo :" + vehicleInfo
				+"\nCar Name:" + carName
				+"\nprice:"  +price
				+"\nNoOfWheels:" + noOfWheels
				+"\nbreakType:" + breakType);
	}
	
}
