package org.cap.demo;

import java.io.Serializable;
import java.util.Scanner;

public class Employee implements Serializable {
	
	private int employeeId;
	private String firstName;
	private String lastName;
	transient private double salary;
	private boolean ispermanent;
	
	public void getEmployee() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter FirstName");
		this.firstName=scanner.next();
		System.out.println("Enter LastName");
		this.lastName=scanner.next();
		System.out.println("Enter Salary:");
		this.salary=scanner.nextDouble();
		System.out.println("Enter EmployeeId:");
		this.employeeId=scanner.nextInt();
		System.out.println("Enter Permanent:");
		this.ispermanent=scanner.nextBoolean();
		
	}
	
	public void printEmployee() {
		System.out.println("Id: " + employeeId +
				"\nFirstName :" + firstName +
				"\nLastname:" + lastName +
				"\nSalary:" + salary + 
				"\n Ispermanent" + ispermanent);
	}

}
