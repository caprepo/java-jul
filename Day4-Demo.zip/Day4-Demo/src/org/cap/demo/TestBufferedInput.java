package org.cap.demo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestBufferedInput {

	public static void main(String[] args) {
		
		File file=new File("C:\\vidavid\\Training\\2020\\Java_13_Jul_to_17_Jul\\data.txt");
		
		try(FileOutputStream fout=new FileOutputStream(file);
				BufferedOutputStream bout=new BufferedOutputStream(fout)){
			
			String str="Good AfterNoon! To All";
			bout.write(str.getBytes());
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		
		byte[] data=new byte[100];
		
		//Read
		File file2=new File("C:\\vidavid\\Training\\2020\\Java_13_Jul_to_17_Jul\\clsDemo\\Day4-Demo\\src\\org\\cap\\demo\\FileDemo.java");
		try(FileInputStream fin=new FileInputStream(file2);
				BufferedInputStream bin=new BufferedInputStream(fin)){
			
			
			while(bin.read(data) != -1) {
				
			System.out.println(new String(data));
			}
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

}
