package org.cap.demo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadertext {

	public static void main(String[] args) {
File file=new File("C:\\vidavid\\Training\\2020\\Java_13_Jul_to_17_Jul\\sample.txt");
		
	int ch=0;
		
		//try with resource handling
		try(FileReader reader=new FileReader(file)) {
			/*
			 * do { ch=(char)reader.read(); System.out.print(ch); }while(ch!=-1);
			 */
			
			while((ch=reader.read())!=-1) {
				System.out.print((char)ch);
			}
			
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
