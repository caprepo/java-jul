package org.cap.demo.thread;

public class MainClass {

	public static void main(String[] args) {
		
		MyThread t1=new MyThread(7,"seven");
		
		MyThread t2=new MyThread(3,"three");
		
		MyThread t3=new MyThread(15);
		
		t1.setPriority(10);
		t2.setPriority(2);
		t3.setPriority(Thread.MAX_PRIORITY);
		
		t1.setDaemon(true);
		
		t1.start();
		t1.run();
		
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t2.start();
		
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t3.start();
		
	
		Thread.yield();
		
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		System.out.println(t3.getPriority());
		
	}

}
