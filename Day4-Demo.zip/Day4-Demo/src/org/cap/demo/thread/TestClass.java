package org.cap.demo.thread;

public class TestClass {

	public static void main(String[] args) {
		MyRunnable runnable=new MyRunnable("Capgemini");
		Thread t1=new Thread(runnable,"t1");
		//t1.start();
		t1.run();
		MyRunnable runnable1=new MyRunnable("Morgan");
		Thread t2=new Thread(runnable1,"t2");
		//t2.start();
		t2.run();
		
	}

}
