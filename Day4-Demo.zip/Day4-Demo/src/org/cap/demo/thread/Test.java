package org.cap.demo.thread;

public class Test {

	public static void main(String[] args) {
		
		Sample t1=new Sample();
		t1.setDaemon(true);
		t1.start();
		
		MyThread t2=new MyThread(4);
		t2.start();
		
		MyThread t3=new MyThread(11);
		t3.start();
		
		
	}

}
