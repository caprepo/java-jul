package org.cap.demo.thread;

public class Sample extends Thread {
	
	@Override
	public void run() {
		for(int i=0;i<1234324324l;i++)
			System.out.println("i="+i);
	}

}
