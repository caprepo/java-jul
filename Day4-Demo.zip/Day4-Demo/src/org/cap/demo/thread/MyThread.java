package org.cap.demo.thread;

public class MyThread extends Thread {
	
	@Override
	public void run() {
		for(int i=1;i<=15;i++)
			System.out.println(i+"*"+this.num+ "=" + (i*this.num) 
					+"===>" + Thread.currentThread().getName());
	}

	private int num;
	
	public MyThread(int num) {
		this.num=num;
	}

	public MyThread(int num,String threadName) {
		super(threadName);
		this.num=num;
	}
	
}
