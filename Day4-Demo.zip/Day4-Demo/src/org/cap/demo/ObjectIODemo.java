package org.cap.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectIODemo {

	public static void main(String[] args) {
		
		File file=new File("C:\\vidavid\\Training\\2020\\Java_13_Jul_to_17_Jul\\employee.dat");
		
		try(FileOutputStream fout=new FileOutputStream(file);
				ObjectOutputStream out=new ObjectOutputStream(fout)){
			Employee employee=new Employee();
			employee.getEmployee();
			
			out.writeObject(employee);
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		
		try(FileInputStream fin=new FileInputStream(file);
				ObjectInputStream in=new ObjectInputStream(fin)){
			
			Employee employee=(Employee)in.readObject();
			employee.printEmployee();
			
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
