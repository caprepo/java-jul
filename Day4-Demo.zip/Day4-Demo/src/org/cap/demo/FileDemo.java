package org.cap.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		File file=new File("C:\\vidavid\\Training\\2020\\Java_13_Jul_to_17_Jul");
		if(file.isDirectory()) {
			String[] names=file.list();
			for(String name:names)
				System.out.println(name);
			System.out.println(file.getFreeSpace());
			System.out.println(file.getTotalSpace());
			System.out.println(file.getUsableSpace());
			
		}else if(file.isFile()) {
			System.out.println("this a File!");
			System.out.println(file.canRead());
			System.out.println(file.canExecute());
			System.out.println(file.canWrite());
		}else {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
