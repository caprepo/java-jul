package org.cap.demo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileHandling {

	public static void main(String[] args) {
		
		File file=new File("C:\\vidavid\\Training\\2020\\Java_13_Jul_to_17_Jul\\sample.txt");
		
		String message="Hello! We are working in text file.";
		
		//try with resource handling
		try(FileWriter writer=new FileWriter(file)) {
			
			writer.write(message);
			
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
