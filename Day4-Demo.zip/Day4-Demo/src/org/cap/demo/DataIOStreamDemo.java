package org.cap.demo;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataIOStreamDemo {

	public static void main(String[] args) {
		
	int employeeId=1009;
	String empname="Tom";
	double salary = 23000;
	boolean isPermenant= true;


File file=new File("C:\\vidavid\\Training\\2020\\Java_13_Jul_to_17_Jul\\employee.txt");

		try(FileOutputStream fout=new FileOutputStream(file);
				DataOutputStream dout=new DataOutputStream(fout)){
			dout.writeInt(employeeId);
			dout.writeDouble(salary);
			dout.writeBoolean(isPermenant);
			dout.write(empname.getBytes());
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		byte[] str=new byte[100];
		try(FileInputStream fin=new FileInputStream(file);
				DataInputStream din=new DataInputStream(fin)){
			System.out.println("EmployeeId:" + din.readInt());
			System.out.println("salary:" + din.readDouble());
			System.out.println("Is Permanent:" + din.readBoolean());
			din.read(str);
			System.out.println("name:" + new String(str));
			
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
