package org.cap;

public class StaticClassDemo {
	int count=100;
	static String name="Static Class";
	
	public void instance_method() {
		System.out.println("instance method");
	}
	
	public static void static_method() {
		System.out.println("Static method");
	}
	
	static class InnerClass{
		int num=100;
		public void show() {
			System.out.println("num" + num);
			//System.out.println("Count" + count);
			System.out.println("Name:" + name);
			
			static_method();
			
			StaticClassDemo obj=new StaticClassDemo();
			System.out.println("Count" + obj.count);
			obj.instance_method();
		}
	}

}
