package org.cap;

public abstract class Circle {

	abstract public void draw();
}
