package org.cap;

public interface Printable {
	
	void print();
	
	interface Showable{
		void show();
	}

}
