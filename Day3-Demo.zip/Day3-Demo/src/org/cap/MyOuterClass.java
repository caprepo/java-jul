package org.cap;

public class MyOuterClass {
	
	public void printDetails() {
		
		class Shape{
			int pointX,pointY;
			public void getPoints() {
				this.pointX=23;
				this.pointY=12;
			}
			public void displayPoints() {
				System.out.println(pointX+"-" + pointY);
			}
		}
		
		Shape shape=new Shape();
		shape.getPoints();shape.displayPoints();
	}
	
	


}
