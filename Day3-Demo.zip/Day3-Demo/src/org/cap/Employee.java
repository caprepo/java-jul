package org.cap;

public class Employee {

	public void calculateSalary() {
		System.out.println("Employee Salary Calculation.");
	}
}
