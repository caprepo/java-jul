package org.cap;

public class MainClass1 {

	public static void main(String[] args) {
		StaticClassDemo demo=new StaticClassDemo();
		demo.instance_method();
		StaticClassDemo.static_method();
		
		StaticClassDemo.InnerClass oClass=new StaticClassDemo.InnerClass();
		oClass.show();
	}

}
