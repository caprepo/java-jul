package org.cap;

import org.cap.OuterClass.InnerClass;

public class MainClass {

	public static void main(String[] args) {
		
		OuterClass outerClass=new OuterClass();
		
		OuterClass.InnerClass in=outerClass.new InnerClass();
		
		outerClass.show();
		//outerClass.display();
		in.display();
		
		//MyOuterClass$1Shape obj=new MyOuterClass$1Shape();
		
		MyOuterClass class1=new MyOuterClass();
		class1.printDetails();
		
	}

}
