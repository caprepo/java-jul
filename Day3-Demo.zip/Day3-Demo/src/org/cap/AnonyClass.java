package org.cap;

public class AnonyClass {

	public static void main(String[] args) {
		
		new Circle() {

			@Override
			public void draw() {
				System.out.println("Draw Circle....");
			}
			
		}.draw();
		
		
		
		Circle circle2=new Circle() {
			
			@Override
			public void draw() {
				// TODO Auto-generated method stub
				
			}
		};
		
		
		
		
		Printable printable=new Printable() {
			
			@Override
			public void print() {
				System.out.println("Printing works goes here...");
				
			}
		};
		
		printable.print();
		//circle.draw();
		
		
		
		
		
		Employee emp=new Employee();
		emp.calculateSalary();
		
		Employee tempEmp=new Employee() {
			int empId=1000;
			public void calculateSalary() {
				System.out.println("Employee Id:" + empId);
				System.out.println("Caclualte Slary for temporary employee.");
				print();
			}
			
			public void print() {
				System.out.println("Print Details");
			}
		};
		
		tempEmp.calculateSalary();
		//tempEmp.print();
		
		
		
		
		
		
		
		
		
		
		
	}

}
