package org.cap.excep.demo;

public class InsufficientBalanceException extends Exception{

	public InsufficientBalanceException() {
		super("Sorry! you do not have sufficient Balance!");
	}
	
	
}
