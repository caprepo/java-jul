package org.cap.excep.demo;

import java.io.IOException;

public class Child extends Parent {

	@Override
	public void show() throws NumberFormatException{
		System.out.println("Child show method....");
	}
}
