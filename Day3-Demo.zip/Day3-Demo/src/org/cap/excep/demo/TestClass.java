package org.cap.excep.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestClass {

	public static void main(String[] args) {
		
		//String num1="34a";
		//int num2=0;
	
		try {
			//File file=new File("asdasd");
			//FileReader reader=new FileReader(file);
			int num1=Integer.parseInt(args[0]);
			int num2=Integer.parseInt(args[1]);
				try {
				int ans=num1/num2;
				System.out.println("Answer:" + ans);
				}catch (IllegalArgumentException e) {
					System.out.println("inner try block:" +e.getMessage());
				}
			//System.exit(0);
		}catch (NumberFormatException|ArrayIndexOutOfBoundsException e) {
			System.out.println("Number Format Error:"+e.getMessage());
		}
		
		finally {
				System.out.println("............Finally Block Executed...............");
			}
		
		/*
			 * catch (ArithmeticException e) { System.out.println("Arithmetic Exception:"+
			 * e.getMessage()); } catch (Exception e) {
			 * System.out.println("Other Exception:"+ e.getMessage()); }
			 */
		
		
		System.out.println("Excecution Continues......");
		 
	}

}
