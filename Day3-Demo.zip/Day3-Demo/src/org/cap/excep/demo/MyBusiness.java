package org.cap.excep.demo;

public class MyBusiness {
	
	public void validateBalance(double amt) throws InsufficientBalanceException {
		if(amt<1000)
			throw new InsufficientBalanceException();
		else
			System.out.println("Your account created!");
	}
	
	
	public void checkAge(int age) {
		
		try {
		if(age<18)
			throw new InvalidAgeException("Age should be greater than 18!");
		}catch (InvalidAgeException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("execution still continues.....");
	}
	
	
	public int divnumbers(String num1,String num2) throws NumberFormatException
		,ArithmeticException{
		
		int n1=Integer.parseInt(num1);
		int n2=Integer.parseInt(num2);
		if(n2==0)
			throw new ArithmeticException("Number is Zero! You can not process!");
		
		return n1/n2;
	}

}
