package org.cap.excep.demo;

public class InvalidAgeException extends RuntimeException{

	
	public InvalidAgeException(String msg) {
		super(msg);
	}
	
}
