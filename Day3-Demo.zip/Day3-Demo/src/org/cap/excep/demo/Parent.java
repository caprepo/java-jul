package org.cap.excep.demo;

import java.io.IOException;

public class Parent {
	
	public void show() throws IOException{
		System.out.println("Parent show method....");
	}

}
