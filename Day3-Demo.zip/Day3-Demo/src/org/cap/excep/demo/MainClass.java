package org.cap.excep.demo;

public class MainClass {

	public static void main(String[] args) {
		MyBusiness business=new MyBusiness();
		
		//business.checkAge(12);
		/*
		 * try { business.validateBalance(200); } catch (InsufficientBalanceException e)
		 * { // TODO Auto-generated catch block e.printStackTrace(); }
		 */
		
		
		
		
		
		
		
		
		
		try {
			int ans=business.divnumbers("230", "0");
			System.out.println("Answer:" + ans);
			
			  }catch (ArithmeticException|NumberFormatException e) { e.printStackTrace();
			  }catch (Exception e) { e.printStackTrace(); }
			 
	}

}
