package org.cap;

public class OuterClass {
	
	int count=100;
	
	public void show() {
		new InnerClass().display();
		System.out.println("OUterClass Show Method");
	}

	 class InnerClass{
		int num;
		public void display() {
			System.out.println("Count:" + count);
			System.out.println("inner Class display method");
		}
		
	
	}
	 
	
}
