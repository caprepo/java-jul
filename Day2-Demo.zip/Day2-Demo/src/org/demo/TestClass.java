package org.demo;
import org.cap.polymrphsm.DailyWorker;
import org.cap.polymrphsm.Worker;

import static org.cap.polymrphsm.Worker.*;
public class TestClass {

	public static void main(String[] args) {
		//Worker worker=new Worker();
		
		//Worker worker=new Worker();
		display();
		DailyWorker dailyWorker =new DailyWorker();
		DailyWorker dailyWorker1 =new DailyWorker("Jack",34.56);
		dailyWorker.printDetails();
		dailyWorker1.printDetails();
	}

}
