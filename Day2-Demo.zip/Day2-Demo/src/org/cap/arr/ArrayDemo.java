package org.cap.arr;

public class ArrayDemo {

	public static void main(String[] args) {
		
		int SIZE=10;
		int[] myarr=new int[SIZE];
		
		int[] nums= {23,45,67,89,90,12};

		//enhanced for loop
		/*
		 * for(int n:nums) { System.out.println(n); }
		 */
		
		for(int i=0;i<nums.length;i++)
			System.out.println(nums[i]);
		
		nums=sort(nums);
		System.out.println();
		
		for(int i=0;i<nums.length;i++)
			System.out.print(nums[i] + " , ");
		System.out.println();
	}
	
	public static int[] sort(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		return arr;
	}

}
