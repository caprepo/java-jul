package org.cap.arr;

import java.util.Scanner;

import org.cap.polymrphsm.Worker;

public class Sample {

	public static void main(String[] args) {
		//declarations
		int[][] nums=new int[2][3];
		
		int[] nums1[]=new int[2][3];
		
		int nums2[][]=new int[2][3];
		
		//intialize
		int numbers[][]= {{1,2,3},{3,4,5},{5,6}};
		
		//single dimention
		Worker[] workers=new Worker[10];
		
		for(int i=0;i<10;i++) {
			workers[i]=new Worker("Worker:" + i);
		}
		
		for(int i=0;i<10;i++) {
			workers[i].printDetails();
		}
		
		
		Scanner scanner=new Scanner(System.in);
		
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
				numbers[i][j]=scanner.nextInt();
			}
		}
		
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
		System.out.print(numbers[i][j]+",");
			}
			System.out.println();
		}
		
		
		
	}

}
