package org.cap.polymrphsm;

public class Customer {
	int customerId;
	String customerName;
	final String branchName="HDFC OMR Branch";
	final int branchCode=1003;
	
	static int count;

	
	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.customerId=34;
		customer.customerName="Tom";
		Customer customer2=new Customer();
		System.out.println(customer.customerId +"-" + customer.customerName);
		System.out.println(customer2.customerId +"-" + customer2.customerName);
		System.out.println(count);
		count=5;
		
		System.out.println(Customer.count);
		System.out.println(Customer.count);
		
		System.out.println(customer.branchCode);
		System.out.println(customer2.branchName);
		//customer.branchCode=7890;
		
		
	}
}
