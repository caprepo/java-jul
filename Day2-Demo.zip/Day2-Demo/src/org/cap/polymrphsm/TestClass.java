package org.cap.polymrphsm;

public class TestClass {

	public static void main(String[] args) {
		Worker worker=new Worker("Tom",23.90);
		worker.printDetails();
		
		Worker worker2=new DailyWorker();
	}

}
