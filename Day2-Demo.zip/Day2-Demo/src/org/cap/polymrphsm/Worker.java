package org.cap.polymrphsm;

import java.util.Scanner;

public class Worker {
	protected String name;
	protected double salaryRate;
	
	//constrcutor
	public Worker() {
		System.out.println("no Arg constrcuctor -Worker");
		
		//Calculation of Salary
		//System.out.println("Calculate Pay.....");
		//printDetails();
	}
	
	public Worker(String name) {
		this.name=name;
		System.out.println("one Arg constrcuctor");
	}
	
	public Worker(String name,double salaryRate) {
		//this.name=name;
		this(name);
		this.salaryRate=salaryRate;
		
		System.out.println("2 Arg constrcuctor");
	}
	
	public void printDetails() {
		System.out.println(name + "-" + salaryRate) ;
	}
	
	
	static int count;
	
	public void getWorkerDetails() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Name:");
		name=scanner.next();
		System.out.println("Enter SalaryRate:");
		salaryRate=scanner.nextDouble();
		
	}
	
	public double comPay(int hours) {
		System.out.println("Calculate Pay.....");
		return 0.0;
	}
	
	{
		System.out.println("============Worker Class Normal Block=================");
	}
	static {
		System.out.println("============Worker Class Static Block=================");
	}
	
	public static void display() {
		System.out.println("Name:" + count);
		System.out.println("Worker Class display method.............");
	}

}
