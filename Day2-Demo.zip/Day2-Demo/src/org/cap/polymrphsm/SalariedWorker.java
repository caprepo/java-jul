package org.cap.polymrphsm;

public class SalariedWorker extends Worker {
	@Override
	public double comPay(final int hours) {
		//getWorkerDetails();
		//hours=90;
		double salary=salaryRate*hours;
		
		return salary;
	}
}
