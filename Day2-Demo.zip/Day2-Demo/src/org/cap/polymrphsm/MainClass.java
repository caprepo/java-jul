package org.cap.polymrphsm;

import java.util.Scanner;

public class MainClass {
	
	//instance variable
	int count;
	

	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		//Reference = new Worker() (Object)
		//Worker worker=new Worker();
		Worker worker=new Worker("Tom",45.90);
		int day_hour=0;
		int choice=0;
		
		Worker.display();
		
		do{
		System.out.println("1.Daily Worker.");
		System.out.println("2.Salaried Worker.");
		choice=scanner.nextInt();
			switch (choice) {
			case 1:
				worker=new DailyWorker();
				System.out.println("Enter no of Days worked:");
				day_hour=scanner.nextInt();
				break;
			case 2:
				worker=new SalariedWorker();
				System.out.println("Enter no of hours worked:");
				day_hour=scanner.nextInt();
				break;
			default:
				System.out.println("Invalid Choice! Try Again!");
				break;
			}
		}while(choice>=1&&choice<=2);
		double salary=worker.comPay(day_hour);
		System.out.println("Computed Salary:"+ salary);
		
	}

}
