package org.cap.polymrphsm;

import java.util.Scanner;

public class DailyWorker extends Worker{
	
	
	public DailyWorker() {
		System.out.println("no Arg Constrcutor - DailyWorlker" );
	}
	
	
	public DailyWorker(String name,double salaryrate) {
		//parent class constructor
		super(name,salaryrate);
		
		System.out.println("no Arg Constrcutor - DailyWorlker" );
	}
	
	
	
	
	
	
	

	@Override
	public double comPay(int days) {
		//getWorkerDetails();
		double salary=salaryRate*days;
		
		return salary;
	}
	
	
	public static void display() {
		System.out.println("Worker Class display method.............");
	}
	
	public static void display(int hour) {
		System.out.println("Worker Class display method.............");
	}
}
