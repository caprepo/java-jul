package org.cap.interfacedemo;

public interface Shape extends Color,Graphics{
	
	void fillColor();
	
	 float pi=32.77f;
	
	 void getPoints();
	  
	 default void draw() {
		 System.out.println("Draw Shape....");
	 }
	  
	  public static void details() {
		  System.out.println("Shape Details here......");
	  }
	  
	  
}
