package org.cap.interfacedemo;

public interface Graphics {
	void moveX();
	void moveY();

}
