package org.cap.interfacedemo;

public class MainClass {

	public static void main(String[] args) {
		
		Circle circle=new Circle();
		Shape shape=new Circle();
		//shape.calculateArea(3.5f);
		shape.draw();
		
		circle.calculateArea(3.5f);
		circle.draw();
		
		Shape.details();
		System.out.println(Shape.pi);
		
	}

}
