package org.cap.interfacedemo;

public class Circle implements Shape{
	
	public void calculateArea(float radius) {
		float area=(22*radius*radius)/7;
		System.out.println("Area:" + area);
	}

	@Override
	public void getPoints() {
		System.out.println("Circle Points to DRAW circle.");
	}

	@Override
	public void draw() {
		 System.out.println("Draw Circle....");
	}

	@Override
	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drawShapeWithColor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moveX() {
		System.out.println("Move X-co ordinates");
	}

	@Override
	public void moveY() {
		System.out.println("Move Y-co ordinates");
	}
	
}
