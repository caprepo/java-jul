package org.cap.interfacedemo;

public interface Color {

	public void fillColor();
	public void drawShapeWithColor();
	
	 default void draw() {
		 System.out.println("Draw with Colors....");
	 }
	
}
