package org.cap.abstractcls;

public class Triangle extends Shape {

	@Override
	public void getPoints() {
		System.out.println("3 points to draw Triangle");
	}

	@Override
	public void draw() {
		System.out.println("Draw Triangle here....");
	}

}
