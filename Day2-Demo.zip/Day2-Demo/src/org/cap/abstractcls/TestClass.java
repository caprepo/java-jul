package org.cap.abstractcls;

public class TestClass {

	public static void main(String[] args) {
		Shape shape=new Circle();
		
		shape.details();
		shape.getPoints();
		shape.draw();
		
		Shape shape2=new Triangle();
		shape2.details();
		shape2.getPoints();
		shape2.draw();
		
	}

}
