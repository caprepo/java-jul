package org.cap.abstractcls;

public class Circle extends Shape{

	@Override
	public void getPoints() {
		System.out.println("One point to draw circle");
	}

	@Override
	public void draw() {
		System.out.println("Draw Circle here....");
	}

}
