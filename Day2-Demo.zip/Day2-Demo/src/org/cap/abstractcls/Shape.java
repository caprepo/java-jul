package org.cap.abstractcls;

public abstract class Shape {
	
	String info;
	
	public void details() {
		System.out.println("details about shape:" + info);
	}
	
	abstract public void getPoints();
	abstract public void draw();

}
