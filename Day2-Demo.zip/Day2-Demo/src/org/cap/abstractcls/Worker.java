package org.cap.abstractcls;

import java.util.Scanner;

public abstract class Worker {
	protected String name;
	protected double salaryRate;
	
	static int count;
	
	public void getWorkerDetails() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Name:");
		name=scanner.next();
		System.out.println("Enter SalaryRate:");
		salaryRate=scanner.nextDouble();
		
	}
	
	abstract public double comPay(int hours);
	
	{
		System.out.println("============Worker Class Normal Block=================");
	}
	static {
		System.out.println("============Worker Class Static Block=================");
	}
	
	public static void display() {
		System.out.println("Name:" + count);
		System.out.println("Worker Class display method.............");
	}

}
